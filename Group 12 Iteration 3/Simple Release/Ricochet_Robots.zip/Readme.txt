To run the application, navigate to the jar file in the command line and then type java -jar Ricochet_Robots.jar



Currently, Start game and load game both works. The robots collides with the barriers and stops.
It also stops when it collides with another robot. However, there is a bug with Robot collision which 
sometimes lets the robots pass through each other. We will 
solve this problem in the final release.

The Save game works and the load game functionality also works. 